"""
Execution logic, surrounding contexts for nodes and graphs and events.

This module is considered **internal**.

"""

import logging

logger = logging.getLogger(__name__)

__all__ = []
