from bonobo.structs.graphs import Graph

__all__ = ['Graph']
