from bonobo.plugins import Plugin
from raven import Client


class SentryPlugin(Plugin):
    pass
